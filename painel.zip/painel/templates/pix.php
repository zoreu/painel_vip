<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Painel</title>
    <link rel="stylesheet" type="text/css" href= "css/default.css">
</head>
<script src="js/default.js"></script>

<body>
    <div class="title">
        <h1>Painel Vip</h1>
    </div>
    <div class="caixa_pix">
        <h2>Doação via Pix Qr Code</h2>
        <div class="pix">
            <img src="https://i.imgur.com/ofrkBkF.png" alt="">
        </div>
    <div>

    <div class="footer">
        <p>Desenvolvido por: Joel Silva, <a href="?action=pix">Doar via PIX</a></p>
    </div>
</body>
</html>